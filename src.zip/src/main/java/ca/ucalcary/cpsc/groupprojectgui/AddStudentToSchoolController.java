package ca.ucalcary.cpsc.groupprojectgui;

public class AddStudentToSchoolController {
}
