package ca.ucalcary.cpsc.groupprojectgui.objects;

public enum ExpenseType{
    GROCERY,
    TUITION,
    RENT
}
